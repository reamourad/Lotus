Zone 3. Nothing important here.
