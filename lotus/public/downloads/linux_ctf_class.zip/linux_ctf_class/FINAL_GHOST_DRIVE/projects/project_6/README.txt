Project 6 notes.
