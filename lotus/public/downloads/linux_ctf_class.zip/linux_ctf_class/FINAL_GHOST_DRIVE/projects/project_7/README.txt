Project 7 notes.
