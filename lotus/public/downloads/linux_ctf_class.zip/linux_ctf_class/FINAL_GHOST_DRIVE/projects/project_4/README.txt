Project 4 notes.
