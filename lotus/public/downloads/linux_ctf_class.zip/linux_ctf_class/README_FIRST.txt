LINUX FOUNDATIONS FOR CTFs
==========================

Recommended order:
1. practice_1_navigation
2. practice_2_find_and_grep
3. practice_3_data_processing
4. practice_4_files_and_archives
5. FINAL_GHOST_DRIVE

The practice sections are meant to be completed with the instructor.
The final Ghost Drive challenge removes command-level guidance.

Do not open INSTRUCTOR_ONLY unless you are teaching or testing the lesson.
